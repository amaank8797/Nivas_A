package com.atithinivas.reviewservice.service;

import com.atithinivas.reviewservice.model.Review;
import com.atithinivas.reviewservice.repository.ReviewRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
public class ReviewService {

    private final ReviewRepository repo;

    public ReviewService(ReviewRepository repo) {
        this.repo = repo;
    }

    public List<Review> getAllReviews() {
        return repo.findAll();
    }

    public List<Review> getReviewsByUser(String userId) {
        return repo.findByUserId(userId);
    }

    public List<Review> getReviewsByHotel(String hotelId) {
        return repo.findByHotelId(hotelId);
    }

    public Review createReview(Review r) {
        // ensure frontend-visible id exists
        if (r.getReviewId() == null || r.getReviewId().isBlank()) {
            r.setReviewId(UUID.randomUUID().toString());
        }
        return repo.save(r);
    }

    @Transactional
    public Review updateReview(String reviewId, Review updates) {
        Review existing = repo.findByReviewId(reviewId)
                .orElseThrow(() -> new ReviewNotFoundException("Review not found: " + reviewId));

        // update only allowed fields (rating + comment)
        if (updates.getComment() != null) existing.setComment(updates.getComment());
        if (updates.getRating() != 0) existing.setRating(updates.getRating());
        // you can add more updatable fields if needed
        return repo.save(existing);
    }

    public void deleteReview(String reviewId) {
        Review existing = repo.findByReviewId(reviewId)
                .orElseThrow(() -> new ReviewNotFoundException("Review not found: " + reviewId));
        repo.delete(existing);
    }

    public Review findByReviewId(String reviewId) {
        return repo.findByReviewId(reviewId)
                .orElseThrow(() -> new ReviewNotFoundException("Review not found: " + reviewId));
    }
}