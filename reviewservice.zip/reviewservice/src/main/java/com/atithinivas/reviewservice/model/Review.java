package com.atithinivas.reviewservice.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "reviews")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;  // internal primary key

    @Column(name = "review_id", unique = true, nullable = false)
    private String reviewId;  // UUID-style id visible to frontend

    @Column(name = "hotel_id", nullable = false)
    private String hotelId;

    @Column(name = "user_id", nullable = false)
    private String userId;

    @NotBlank
    @Size(max = 1000)
    private String comment;

    @Min(1)
    @Max(5)
    private int rating;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @PrePersist
    public void prePersist() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    public void preUpdate() {
        updatedAt = LocalDateTime.now();
    }
}