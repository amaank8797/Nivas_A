package com.atithinivas.reviewservice.repository;

import com.atithinivas.reviewservice.model.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {
    Optional<Review> findByReviewId(String reviewId);
    List<Review> findByUserId(String userId);
    List<Review> findByHotelId(String hotelId);
    void deleteByReviewId(String reviewId);
    boolean existsByReviewId(String reviewId);
}