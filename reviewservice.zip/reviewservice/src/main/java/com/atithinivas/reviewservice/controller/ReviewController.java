package com.atithinivas.reviewservice.controller;

import com.atithinivas.reviewservice.model.Review;
import com.atithinivas.reviewservice.service.ReviewService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/reviews")
public class ReviewController {

    private final ReviewService svc;

    public ReviewController(ReviewService svc) {
        this.svc = svc;
    }

    // GET /api/v1/reviews
    @GetMapping
    public List<Review> listAll() {
        return svc.getAllReviews();
    }

    // GET /api/v1/reviews/user/{userId}
    @GetMapping("/user/{userId}")
    public List<Review> byUser(@PathVariable String userId) {
        return svc.getReviewsByUser(userId);
    }

    // GET /api/v1/reviews/hotel/{hotelId}
    @GetMapping("/hotel/{hotelId}")
    public List<Review> byHotel(@PathVariable String hotelId) {
        return svc.getReviewsByHotel(hotelId);
    }

    // GET /api/v1/reviews/{reviewId}
    @GetMapping("/{reviewId}")
    public ResponseEntity<Review> getOne(@PathVariable String reviewId) {
        return ResponseEntity.ok(svc.findByReviewId(reviewId));
    }

    // POST /api/v1/reviews
    @PostMapping
    public ResponseEntity<Review> create(@Valid @RequestBody Review r) {
        Review created = svc.createReview(r);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    // PATCH /api/v1/reviews/{reviewId}
    @PatchMapping("/{reviewId}")
    public ResponseEntity<Review> patch(
            @PathVariable String reviewId,
            @RequestBody Map<String, Object> updates
    ) {
        Review tmp = new Review();
        if (updates.containsKey("comment")) {
            Object c = updates.get("comment");
            tmp.setComment(c == null ? null : String.valueOf(c));
        }
        if (updates.containsKey("rating")) {
            Object o = updates.get("rating");
            int parsedRating;
            if (o instanceof Number) {
                parsedRating = ((Number) o).intValue();
            } else {
                parsedRating = Integer.parseInt(String.valueOf(o));
            }
            tmp.setRating(parsedRating);
        }

        Review updated = svc.updateReview(reviewId, tmp);
        return ResponseEntity.ok(updated);
    }

    // DELETE /api/v1/reviews/{reviewId}
    @DeleteMapping("/{reviewId}")
    public ResponseEntity<Void> delete(@PathVariable String reviewId) {
        svc.deleteReview(reviewId);
        return ResponseEntity.noContent().build();
    }

    // Basic exception mapping (controller-level)
    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<Map<String, String>> handleRuntime(RuntimeException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("error", ex.getMessage()));
    }
}